ToLD-BR

Description:
This is a randomly selected sample of a 100 tweets from ToLD-BR in csv format.
In it's full version, ToLD-BR consists of 21000 manually labeled tweets as zero or more of the 
following categories: LGBTQ+phobia, Obscene, Insult, Racism, Misogyny or Xenophobia.
Each example was annotated by three annotators. The dataset consists of a column "text" with the
tweet that was tagged and three columns for each class, corresponding to the annotation of
each annotator. 0 indicates non-toxic for a specific class, 1 indicates toxic. All user mentions (@)
were substituted by a @user token.

Columns:
text, lgbtq+phobia_1, obscene_1, insult_1, racism_1, misogyny_1, xenophobia_1, lgbtq+phobia_2, obscene_2, insult_2, racism_2, misogyny_2, xenophobia_2, lgbtq+phobia_3, obscene_3, insult_3, racism_3, misogyny_3, xenophobia_3 